-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: MyPOS
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Banks`
--

DROP TABLE IF EXISTS `Banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Banks` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Banks`
--

LOCK TABLES `Banks` WRITE;
/*!40000 ALTER TABLE `Banks` DISABLE KEYS */;
INSERT INTO `Banks` VALUES (1,'yooow','123','2025-07-10 10:10:48','2025-07-10 10:10:48');
/*!40000 ALTER TABLE `Banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Brand`
--

DROP TABLE IF EXISTS `Brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Brand` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Brand`
--

LOCK TABLES `Brand` WRITE;
/*!40000 ALTER TABLE `Brand` DISABLE KEYS */;
INSERT INTO `Brand` VALUES (1,'Panda'),(2,'MCDO');
/*!40000 ALTER TABLE `Brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Categories`
--

LOCK TABLES `Categories` WRITE;
/*!40000 ALTER TABLE `Categories` DISABLE KEYS */;
INSERT INTO `Categories` VALUES (1,'School supply','2025-07-09 09:16:42','2025-07-09 09:16:42'),(2,'Food','2025-07-10 15:01:30','2025-07-10 15:01:30');
/*!40000 ALTER TABLE `Categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `customer_code` int(11) DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (1,'Elong mass',1100,'123','star link','2025-07-10 10:11:30','2025-07-10 10:11:30');
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `End_Of_Day_Summary`
--

DROP TABLE IF EXISTS `End_Of_Day_Summary`;
/*!50001 DROP VIEW IF EXISTS `End_Of_Day_Summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `End_Of_Day_Summary` AS SELECT
 1 AS `invoice_date`,
  1 AS `Total_Sales`,
  1 AS `Total_Transactions`,
  1 AS `Total_Items_Sold`,
  1 AS `Total_Cash`,
  1 AS `Total_Profit` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `Inventory_Status`
--

DROP TABLE IF EXISTS `Inventory_Status`;
/*!50001 DROP VIEW IF EXISTS `Inventory_Status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Inventory_Status` AS SELECT
 1 AS `product_id`,
  1 AS `product_name`,
  1 AS `size`,
  1 AS `color`,
  1 AS `current_stock_quantity`,
  1 AS `restock_level` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Invoices`
--

DROP TABLE IF EXISTS `Invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Invoices` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `invoice_date` date DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`invoice_id`),
  KEY `customer_id` (`customer_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Invoices_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `Customers` (`customer_id`),
  CONSTRAINT `Invoices_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoices`
--

LOCK TABLES `Invoices` WRITE;
/*!40000 ALTER TABLE `Invoices` DISABLE KEYS */;
INSERT INTO `Invoices` VALUES (1,1,'2025-07-10',1,'2025-07-10 10:15:28','2025-07-12 14:19:35');
/*!40000 ALTER TABLE `Invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Invoices_Total_Sales`
--

DROP TABLE IF EXISTS `Invoices_Total_Sales`;
/*!50001 DROP VIEW IF EXISTS `Invoices_Total_Sales`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Invoices_Total_Sales` AS SELECT
 1 AS `invoice_id`,
  1 AS `invoice_date`,
  1 AS `customer_name`,
  1 AS `username`,
  1 AS `Calculated_Total_Amount`,
  1 AS `Total_Paid`,
  1 AS `Balance`,
  1 AS `Payment_Status` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `PaymentMethods`
--

DROP TABLE IF EXISTS `PaymentMethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PaymentMethods` (
  `payment_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `method_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PaymentMethods`
--

LOCK TABLES `PaymentMethods` WRITE;
/*!40000 ALTER TABLE `PaymentMethods` DISABLE KEYS */;
INSERT INTO `PaymentMethods` VALUES (1,'Gcash',NULL,'2025-07-10 10:15:47','2025-07-10 10:15:47');
/*!40000 ALTER TABLE `PaymentMethods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Payment_Breakdown`
--

DROP TABLE IF EXISTS `Payment_Breakdown`;
/*!50001 DROP VIEW IF EXISTS `Payment_Breakdown`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Payment_Breakdown` AS SELECT
 1 AS `invoice_id`,
  1 AS `customer_name`,
  1 AS `method_name`,
  1 AS `amount`,
  1 AS `payment_date`,
  1 AS `username` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Payments`
--

DROP TABLE IF EXISTS `Payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `bank_id` (`bank_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Payments_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `Invoices` (`invoice_id`),
  CONSTRAINT `Payments_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `PaymentMethods` (`payment_method_id`),
  CONSTRAINT `Payments_ibfk_3` FOREIGN KEY (`bank_id`) REFERENCES `Banks` (`bank_id`),
  CONSTRAINT `Payments_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payments`
--

LOCK TABLES `Payments` WRITE;
/*!40000 ALTER TABLE `Payments` DISABLE KEYS */;
INSERT INTO `Payments` VALUES (1,1,1,100,1,'2025-07-10 10:15:54',1);
/*!40000 ALTER TABLE `Payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductVariants`
--

DROP TABLE IF EXISTS `ProductVariants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProductVariants` (
  `variant_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `color` varchar(100) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `base_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `current_stock_quantity` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`variant_id`),
  KEY `product_id` (`product_id`),
  KEY `unit_id` (`unit_id`),
  CONSTRAINT `ProductVariants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `Products` (`product_id`),
  CONSTRAINT `ProductVariants_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductVariants`
--

LOCK TABLES `ProductVariants` WRITE;
/*!40000 ALTER TABLE `ProductVariants` DISABLE KEYS */;
INSERT INTO `ProductVariants` VALUES (1,1,'small','0.6kg','red',1,8.00,2.00,30,'2025-07-09 09:19:00','2025-07-22 16:04:32'),(2,2,'large','0.12kl','red',1,15.00,8.00,30,'2025-07-10 15:00:04','2025-07-22 16:04:38');
/*!40000 ALTER TABLE `ProductVariants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) DEFAULT NULL,
  `product_code` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`),
  KEY `brand_id` (`brand_id`),
  KEY `category_id` (`category_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `Products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `Categories` (`category_id`),
  CONSTRAINT `Products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `Brand` (`brand_id`),
  CONSTRAINT `Products_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Products`
--

LOCK TABLES `Products` WRITE;
/*!40000 ALTER TABLE `Products` DISABLE KEYS */;
INSERT INTO `Products` VALUES (1,'Pen',1001,'yohoo',1,1,1,'2025-07-09 09:15:21','2025-07-11 11:18:15'),(2,'bolalo',1002,'food',2,2,1,'2025-07-10 14:58:37','2025-07-11 11:18:23');
/*!40000 ALTER TABLE `Products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Profit_For_Product`
--

DROP TABLE IF EXISTS `Profit_For_Product`;
/*!50001 DROP VIEW IF EXISTS `Profit_For_Product`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Profit_For_Product` AS SELECT
 1 AS `product_id`,
  1 AS `product_name`,
  1 AS `cost_price`,
  1 AS `base_price`,
  1 AS `ordered_quantity`,
  1 AS `sold_quantity`,
  1 AS `total_cost`,
  1 AS `expected_sales`,
  1 AS `total_profit` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `Profit_Per_Product_Per_Invoice`
--

DROP TABLE IF EXISTS `Profit_Per_Product_Per_Invoice`;
/*!50001 DROP VIEW IF EXISTS `Profit_Per_Product_Per_Invoice`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Profit_Per_Product_Per_Invoice` AS SELECT
 1 AS `product_id`,
  1 AS `product_name`,
  1 AS `cost_price`,
  1 AS `base_price`,
  1 AS `invoice_date`,
  1 AS `sold_quantity`,
  1 AS `total_cost`,
  1 AS `expected_sales`,
  1 AS `total_profit` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `PurchaseOrderItems`
--

DROP TABLE IF EXISTS `PurchaseOrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PurchaseOrderItems` (
  `Purchase_Orders_Items_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `ordered_quantity` int(11) DEFAULT NULL,
  `purchase_cost_price` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Purchase_Orders_Items_id`),
  KEY `variant_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `PurchaseOrderItems_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers` (`supplier_id`),
  CONSTRAINT `PurchaseOrderItems_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `Products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrderItems`
--

LOCK TABLES `PurchaseOrderItems` WRITE;
/*!40000 ALTER TABLE `PurchaseOrderItems` DISABLE KEYS */;
INSERT INTO `PurchaseOrderItems` VALUES (1,1,1,20,2,'2025-07-09 09:21:55','2025-07-23 10:52:53'),(2,2,1,20,8,'2025-07-10 15:06:03','2025-07-23 10:52:57');
/*!40000 ALTER TABLE `PurchaseOrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PurchaseOrders`
--

DROP TABLE IF EXISTS `PurchaseOrders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PurchaseOrders` (
  `Purchase_Orders_id` int(11) NOT NULL,
  `Purchase_Orders_Items_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Purchase_Orders_id`),
  KEY `product_id` (`order_date`),
  KEY `supplier_id` (`supplier_id`),
  KEY `status_id` (`status_id`),
  KEY `Purchase_Orders_Items_id` (`Purchase_Orders_Items_id`),
  CONSTRAINT `PurchaseOrders_ibfk_1` FOREIGN KEY (`status_id`) REFERENCES `PurhcaseOrderStatus` (`status_id`),
  CONSTRAINT `PurchaseOrders_ibfk_2` FOREIGN KEY (`Purchase_Orders_Items_id`) REFERENCES `PurchaseOrderItems` (`Purchase_Orders_Items_id`),
  CONSTRAINT `PurchaseOrders_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrders`
--

LOCK TABLES `PurchaseOrders` WRITE;
/*!40000 ALTER TABLE `PurchaseOrders` DISABLE KEYS */;
INSERT INTO `PurchaseOrders` VALUES (1,1,1,'2025-07-09',1,'2025-07-09 09:23:19','2025-07-23 15:20:28'),(2,2,1,'2025-07-11',2,'2025-07-10 15:04:21','2025-07-23 15:20:33');
/*!40000 ALTER TABLE `PurchaseOrders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Purchase_Orders_Summary`
--

DROP TABLE IF EXISTS `Purchase_Orders_Summary`;
/*!50001 DROP VIEW IF EXISTS `Purchase_Orders_Summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Purchase_Orders_Summary` AS SELECT
 1 AS `Purchase_Orders_Items_id`,
  1 AS `supplier_name`,
  1 AS `product_name`,
  1 AS `ordered_quantity`,
  1 AS `purchase_cost_price`,
  1 AS `subtotal`,
  1 AS `order_date`,
  1 AS `status_name` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `PurhcaseOrderStatus`
--

DROP TABLE IF EXISTS `PurhcaseOrderStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PurhcaseOrderStatus` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` enum('Received','Process','Pending','Canceled') DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurhcaseOrderStatus`
--

LOCK TABLES `PurhcaseOrderStatus` WRITE;
/*!40000 ALTER TABLE `PurhcaseOrderStatus` DISABLE KEYS */;
INSERT INTO `PurhcaseOrderStatus` VALUES (1,'Received'),(2,'Process'),(3,'Pending'),(4,'Canceled');
/*!40000 ALTER TABLE `PurhcaseOrderStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReceiveProducts`
--

DROP TABLE IF EXISTS `ReceiveProducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReceiveProducts` (
  `receive_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `Purchase_Orders_id` int(11) DEFAULT NULL,
  `received_quantity` int(11) DEFAULT NULL,
  `cost_price` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `received_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`receive_product_id`),
  KEY `product_id` (`supplier_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `variant_id` (`product_id`),
  KEY `Purchase_Orders_id` (`Purchase_Orders_id`),
  CONSTRAINT `ReceiveProducts_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `Products` (`product_id`),
  CONSTRAINT `ReceiveProducts_ibfk_2` FOREIGN KEY (`Purchase_Orders_id`) REFERENCES `PurchaseOrders` (`Purchase_Orders_id`),
  CONSTRAINT `ReceiveProducts_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers` (`supplier_id`),
  CONSTRAINT `ReceiveProducts_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReceiveProducts`
--

LOCK TABLES `ReceiveProducts` WRITE;
/*!40000 ALTER TABLE `ReceiveProducts` DISABLE KEYS */;
INSERT INTO `ReceiveProducts` VALUES (1,1,1,20,2,1,'2025-07-09',1,'2025-07-09 09:43:13','2025-07-22 20:38:50'),(2,2,2,20,8,1,'2025-07-22',1,'2025-07-22 11:16:56','2025-07-23 09:44:16');
/*!40000 ALTER TABLE `ReceiveProducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sales`
--

DROP TABLE IF EXISTS `Sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`sales_id`),
  KEY `invoice_id` (`invoice_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `variant_id` (`variant_id`),
  CONSTRAINT `Sales_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `Invoices` (`invoice_id`),
  CONSTRAINT `Sales_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `Products` (`product_id`),
  CONSTRAINT `Sales_ibfk_3` FOREIGN KEY (`variant_id`) REFERENCES `ProductVariants` (`variant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sales`
--

LOCK TABLES `Sales` WRITE;
/*!40000 ALTER TABLE `Sales` DISABLE KEYS */;
INSERT INTO `Sales` VALUES (1,1,1,1,2,'2025-07-10 10:26:59','2025-07-12 15:57:59'),(2,1,2,2,20,'2025-07-22 12:17:30','2025-07-22 12:17:40');
/*!40000 ALTER TABLE `Sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Sales_Summary`
--

DROP TABLE IF EXISTS `Sales_Summary`;
/*!50001 DROP VIEW IF EXISTS `Sales_Summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Sales_Summary` AS SELECT
 1 AS `sales_id`,
  1 AS `invoice_id`,
  1 AS `invoice_date`,
  1 AS `product_name`,
  1 AS `quantity`,
  1 AS `base_price`,
  1 AS `Subtotal`,
  1 AS `username` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Suppliers`
--

DROP TABLE IF EXISTS `Suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(15) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  `supplier_contact` varchar(15) NOT NULL,
  `supplier_address` varchar(100) NOT NULL,
  `supplier_email` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Suppliers`
--

LOCK TABLES `Suppliers` WRITE;
/*!40000 ALTER TABLE `Suppliers` DISABLE KEYS */;
INSERT INTO `Suppliers` VALUES (1,'1010','dragon','','','','2025-07-09 09:39:24','2025-07-09 09:39:24');
/*!40000 ALTER TABLE `Suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Units`
--

DROP TABLE IF EXISTS `Units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Units` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(100) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Units`
--

LOCK TABLES `Units` WRITE;
/*!40000 ALTER TABLE `Units` DISABLE KEYS */;
INSERT INTO `Units` VALUES (1,'pcs','2025-07-09 09:20:03','2025-07-09 09:20:03');
/*!40000 ALTER TABLE `Units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserRoles`
--

DROP TABLE IF EXISTS `UserRoles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserRoles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserRoles`
--

LOCK TABLES `UserRoles` WRITE;
/*!40000 ALTER TABLE `UserRoles` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserRoles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(225) DEFAULT NULL,
  `password_hash` varchar(225) DEFAULT NULL,
  `fullname` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'rj','asd','','',NULL,'2025-07-09 09:42:33','2025-07-09 09:42:33');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `End_Of_Day_Summary`
--

/*!50001 DROP VIEW IF EXISTS `End_Of_Day_Summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `End_Of_Day_Summary` AS select `i`.`invoice_date` AS `invoice_date`,coalesce(sum(`pv`.`base_price` * `s`.`quantity`),0) AS `Total_Sales`,count(distinct `i`.`invoice_id`) AS `Total_Transactions`,coalesce(sum(`s`.`quantity`),0) AS `Total_Items_Sold`,coalesce(sum(distinct `pa`.`amount`),0) AS `Total_Cash`,sum((`pv`.`base_price` - `pv`.`cost_price`) * `s`.`quantity`) AS `Total_Profit` from (((`Invoices` `i` join `Sales` `s` on(`s`.`invoice_id` = `i`.`invoice_id`)) join `ProductVariants` `pv` on(`s`.`variant_id` = `pv`.`variant_id`)) left join `Payments` `pa` on(`pa`.`invoice_id` = `i`.`invoice_id`)) group by `i`.`invoice_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Inventory_Status`
--

/*!50001 DROP VIEW IF EXISTS `Inventory_Status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Inventory_Status` AS select `p`.`product_id` AS `product_id`,`p`.`product_name` AS `product_name`,`pv`.`size` AS `size`,`pv`.`color` AS `color`,`pv`.`current_stock_quantity` AS `current_stock_quantity`,`pv`.`current_stock_quantity` - `s`.`quantity` AS `restock_level` from ((`Products` `p` join `ProductVariants` `pv` on(`p`.`product_id` = `pv`.`product_id`)) join `Sales` `s` on(`p`.`product_id` = `s`.`product_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Invoices_Total_Sales`
--

/*!50001 DROP VIEW IF EXISTS `Invoices_Total_Sales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Invoices_Total_Sales` AS select `i`.`invoice_id` AS `invoice_id`,`i`.`invoice_date` AS `invoice_date`,`c`.`customer_name` AS `customer_name`,`u`.`username` AS `username`,`s`.`quantity` * `pv`.`base_price` AS `Calculated_Total_Amount`,`pa`.`amount` AS `Total_Paid`,greatest(`s`.`quantity` * `pv`.`base_price` - `pa`.`amount`,0) AS `Balance`,case when `s`.`quantity` * `pv`.`base_price` <= `pa`.`amount` then 'Paid' when `pa`.`amount` > 0 then 'Partial' else 'Unpaid' end AS `Payment_Status` from (((((`Invoices` `i` join `Customers` `c` on(`i`.`customer_id` = `c`.`customer_id`)) join `Users` `u` on(`i`.`user_id` = `u`.`user_id`)) join `Sales` `s` on(`i`.`invoice_id` = `s`.`invoice_id`)) join `ProductVariants` `pv` on(`s`.`variant_id` = `pv`.`variant_id`)) join `Payments` `pa` on(`i`.`invoice_id` = `pa`.`invoice_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Payment_Breakdown`
--

/*!50001 DROP VIEW IF EXISTS `Payment_Breakdown`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Payment_Breakdown` AS select `i`.`invoice_id` AS `invoice_id`,`c`.`customer_name` AS `customer_name`,`pm`.`method_name` AS `method_name`,`p`.`amount` AS `amount`,`p`.`payment_date` AS `payment_date`,`u`.`username` AS `username` from ((((`Payments` `p` join `Invoices` `i` on(`p`.`invoice_id` = `i`.`invoice_id`)) left join `Customers` `c` on(`c`.`customer_id` = `i`.`customer_id`)) left join `Users` `u` on(`p`.`user_id` = `u`.`user_id`)) left join `PaymentMethods` `pm` on(`p`.`payment_method_id` = `pm`.`payment_method_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Profit_For_Product`
--

/*!50001 DROP VIEW IF EXISTS `Profit_For_Product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Profit_For_Product` AS select `p`.`product_id` AS `product_id`,`p`.`product_name` AS `product_name`,`pv`.`cost_price` AS `cost_price`,`pv`.`base_price` AS `base_price`,`po`.`ordered_quantity` AS `ordered_quantity`,sum(coalesce(`s`.`quantity`,0)) AS `sold_quantity`,`pv`.`cost_price` * sum(coalesce(`s`.`quantity`,0)) AS `total_cost`,`pv`.`base_price` * sum(coalesce(`s`.`quantity`,0)) AS `expected_sales`,(`pv`.`base_price` - `pv`.`cost_price`) * sum(coalesce(`s`.`quantity`,0)) AS `total_profit` from (((`Products` `p` join `ProductVariants` `pv` on(`p`.`product_id` = `pv`.`product_id`)) left join `PurchaseOrderItems` `po` on(`po`.`product_id` = `pv`.`variant_id`)) left join `Sales` `s` on(`s`.`product_id` = `p`.`product_id`)) group by `p`.`product_id`,`p`.`product_name`,`pv`.`cost_price`,`pv`.`base_price`,`po`.`ordered_quantity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Profit_Per_Product_Per_Invoice`
--

/*!50001 DROP VIEW IF EXISTS `Profit_Per_Product_Per_Invoice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Profit_Per_Product_Per_Invoice` AS select `p`.`product_id` AS `product_id`,`p`.`product_name` AS `product_name`,`pv`.`cost_price` AS `cost_price`,`pv`.`base_price` AS `base_price`,`i`.`invoice_date` AS `invoice_date`,`s`.`quantity` AS `sold_quantity`,`pv`.`cost_price` * `s`.`quantity` AS `total_cost`,`pv`.`base_price` * `s`.`quantity` AS `expected_sales`,(`pv`.`base_price` - `pv`.`cost_price`) * `s`.`quantity` AS `total_profit` from (((`Products` `p` join `ProductVariants` `pv` on(`p`.`product_id` = `pv`.`product_id`)) left join `Sales` `s` on(`s`.`product_id` = `p`.`product_id` and `s`.`variant_id` = `pv`.`variant_id`)) left join `Invoices` `i` on(`s`.`invoice_id` = `i`.`invoice_id`)) group by `p`.`product_id`,`p`.`product_name`,`pv`.`cost_price`,`pv`.`base_price`,`i`.`invoice_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Purchase_Orders_Summary`
--

/*!50001 DROP VIEW IF EXISTS `Purchase_Orders_Summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Purchase_Orders_Summary` AS select `poi`.`Purchase_Orders_Items_id` AS `Purchase_Orders_Items_id`,`s`.`supplier_name` AS `supplier_name`,`p`.`product_name` AS `product_name`,`poi`.`ordered_quantity` AS `ordered_quantity`,`poi`.`purchase_cost_price` AS `purchase_cost_price`,`poi`.`ordered_quantity` * `poi`.`purchase_cost_price` AS `subtotal`,`po`.`order_date` AS `order_date`,`pos`.`status_name` AS `status_name` from ((((`PurchaseOrderItems` `poi` join `Suppliers` `s` on(`poi`.`supplier_id` = `s`.`supplier_id`)) join `Products` `p` on(`poi`.`product_id` = `p`.`product_id`)) left join `PurchaseOrders` `po` on(`po`.`status_id` = `poi`.`Purchase_Orders_Items_id`)) left join `PurhcaseOrderStatus` `pos` on(`po`.`status_id` = `pos`.`status_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Sales_Summary`
--

/*!50001 DROP VIEW IF EXISTS `Sales_Summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Sales_Summary` AS select `s`.`sales_id` AS `sales_id`,`i`.`invoice_id` AS `invoice_id`,`i`.`invoice_date` AS `invoice_date`,`p`.`product_name` AS `product_name`,`s`.`quantity` AS `quantity`,`pv`.`base_price` AS `base_price`,`s`.`quantity` * `pv`.`base_price` AS `Subtotal`,`u`.`username` AS `username` from ((((`Sales` `s` join `Invoices` `i` on(`s`.`invoice_id` = `i`.`invoice_id`)) join `ProductVariants` `pv` on(`pv`.`variant_id` = `s`.`variant_id`)) join `Products` `p` on(`pv`.`product_id` = `p`.`product_id`)) join `Users` `u` on(`u`.`user_id` = `i`.`user_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-26 10:15:33
